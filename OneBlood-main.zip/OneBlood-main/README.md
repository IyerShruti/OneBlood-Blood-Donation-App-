# OneBlood
This is a blood bank website where donors can view different blood donation camps and blood banks where they can donate blood, also people who want to receive blood can also view places where they can get the same. Blood Banks can register so that people can check out the details of the bank


To open the webiste run the Index.aspx to begin
You can see the home pagfe at the beginning
To login click on the login button
Sign In if you already have an account or else click on new user

In the home page user can either choose to donate which will lead to a quiz where user can check the usability
also user can search for blood banks by clciking on recieve which will display the stocks of each blood bank
